package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var toggle: Button
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var active = false
    private var waitingForCommand = false
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        transcript = findViewById(R.id.transcript)
        toggle = findViewById(R.id.toggle)
        tts = TextToSpeech(this, this)

        toggle.setOnClickListener {
            if (active) stopListening() else requestMicAndStart()
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Bu telefonda konuşma tanıma hizmeti bulunamadı."
            toggle.isEnabled = false
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale("tr", "TR"))
            ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                       languageResult != TextToSpeech.LANG_NOT_SUPPORTED
        }
    }

    private fun requestMicAndStart() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        } else startListening()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else status.text = "Mikrofon izni olmadan dinleyemem."
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        active = true
        waitingForCommand = false
        toggle.text = "Dinlemeyi durdur"
        status.text = "Dinliyorum. Bana “ASENA” diye seslen."
        createRecognizer()
        listen()
    }

    private fun createRecognizer() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text =
                if (waitingForCommand) "Seni dinliyorum..." else "“ASENA” demeni bekliyorum..." }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Ses işleniyor..." }
            override fun onError(error: Int) {
                if (active && !isFinishing) listen()
            }
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull().orEmpty()
                if (said.isNotBlank()) transcript.text = "Duyduğum: $said"
                if (!active) return
                if (!waitingForCommand && (said.lowercase(Locale("tr", "TR")).contains("asena") ||
                    said.lowercase(Locale("tr", "TR")).contains("asena"))) {
                    waitingForCommand = true
                    speak("Buyur, nasıl yardımcı olayım?")
                } else if (waitingForCommand && said.isNotBlank()) {
                    waitingForCommand = false
                    handleCommand(said)
                } else listen()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun listen() {
        if (!active) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            status.text = "Dinleme başlatılamadı. Tekrar deneyebilirsin."
        }
    }

    private fun speak(message: String) {
        status.text = message
        if (ttsReady) {
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "asena_reply")
            // Wait briefly for speech to finish before listening again.
            android.os.Handler(mainLooper).postDelayed({ if (active) listen() }, 2200)
        } else listen()
    }

    private fun handleCommand(command: String) {
        val c = command.lowercase(Locale("tr", "TR"))
        when {
            c.contains("saat") -> speak("Saat şu an " + SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date()))
            c.contains("tarih") || c.contains("bugün günlerden") ->
                speak("Bugün " + SimpleDateFormat("d MMMM yyyy, EEEE", Locale("tr", "TR")).format(Date()))
            c.contains("youtube") -> {
                openWeb("https://www.youtube.com")
                speak("YouTube'u açıyorum.")
            }
            c.contains("google") || c.contains("internette ara") -> {
                openWeb("https://www.google.com")
                speak("Google'ı açıyorum.")
            }
            c.contains("ayarlar") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                speak("Ayarları açıyorum.")
            }
            c.contains("dur") || c.contains("kapat") -> stopListening()
            else -> speak("Bu komutu henüz yapamıyorum. İlk sürümde saat, tarih, Google, YouTube ve ayarları deneyebilirsin.")
        }
    }

    private fun openWeb(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))) }
        catch (_: Exception) { speak("Bu sayfayı açamadım.") }
    }

    private fun stopListening() {
        active = false
        waitingForCommand = false
        recognizer?.cancel()
        status.text = "Dinleme durduruldu."
        toggle.text = "Dinlemeyi başlat"
    }

    override fun onDestroy() {
        active = false
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
