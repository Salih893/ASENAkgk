ASENA - Android sesli asistan prototipi

Uyandırma kelimesi: ASENA
Yanıtı: "Buyur, nasıl yardımcı olayım?"

Bu ilk prototip uygulama ekranda açıkken Android konuşma tanıma servisiyle ASENA kelimesini
algılar. Saat, tarih, Google, YouTube, Ayarlar ve dinlemeyi durdur komutları bulunur.

ÖNEMLİ:
- ZIP doğrudan kurulabilir APK değildir; Android kaynak projesidir.
- Ekran kilitliyken/arka plandayken sürekli dinleme bu ilk sürümde yoktur.
- Mikrofon izni ve cihazın konuşma tanıma hizmeti gerekir.
- Uygulama Android Studio/Gradle ile derlenmelidir.

GitHub Actions kullanarak bilgisayar olmadan APK derlemek için:
1. Bu ZIP'i ASENA adlı GitHub deposunun köküne yükleyin.
2. Depoda .github/workflows/build.yml yolunda ayrı bir workflow dosyası oluşturun.
3. Sohbette verilen build.yml içeriğini yapıştırıp Commit changes yapın.
4. Actions > ASENA APK Build > Run workflow seçin.
5. İşlem tamamlanınca ASENA-APK artifact'ini indirin.
