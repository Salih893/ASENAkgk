package com.asena.assistant

import android.service.notification.NotificationListenerService

// Android shows a separate system settings screen and the user must explicitly enable access.
// This starter intentionally does not forward or store notification contents.
class AsenaNotificationListener : NotificationListenerService()
