package com.asena.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AsenaVoiceService : Service(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var restarting = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val notification: Notification = NotificationCompat.Builder(this, "asena_mic")
            .setContentTitle("ASENA aktif")
            .setContentText("Sesli asistan çalışıyor. Durdurmak için uygulamayı aç.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(41, notification)
        tts = TextToSpeech(this, this)
        beginListening()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("asena_mic", "ASENA mikrofon", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun beginListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { restartListening() }
            override fun onResults(results: Bundle?) {
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (spoken.isNotBlank()) handleCommand(spoken)
                restartListening()
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) { restartListening() }
    }

    private fun restartListening() {
        if (restarting) return
        restarting = true
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
        restarting = false
        // Restart is event-driven; SpeechRecognizer may stop under battery or OS restrictions.
        beginListening()
    }

    private fun handleCommand(raw: String) {
        val text = raw.lowercase(Locale("tr", "TR"))
        val answer = when {
            "merhaba" in text || "selam" in text -> "Merhaba. Ben ASENA. Nasıl yardımcı olayım?"
            "saat kaç" in text -> "Saat şu anda " + SimpleDateFormat("HH:mm", Locale("tr", "TR")).format(Date())
            "nasılsın" in text -> "İyiyim, teşekkür ederim. Seni dinliyorum."
            "adın ne" in text -> "Benim adım ASENA."
            "durdur" in text || "sus" == text -> "Tamam. Asistanı uygulamadan durdurabilirsin."
            else -> "Komutunu duydum: $raw. Bu komut henüz tanımlı değil."
        }
        if (ready) tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "asena_reply")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            val result = engine.setLanguage(Locale("tr", "TR"))
            ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            val femaleVoice = engine.voices?.firstOrNull {
                it.locale.language == "tr" && it.features?.contains("female") == true
            }
            if (femaleVoice != null) engine.voice = femaleVoice
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
