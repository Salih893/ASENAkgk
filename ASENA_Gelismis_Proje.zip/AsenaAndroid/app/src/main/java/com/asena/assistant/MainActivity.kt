package com.asena.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.util.Locale
import java.util.concurrent.Executor

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var info: TextView
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private lateinit var executor: Executor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = ContextCompat.getMainExecutor(this)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
        }
        val title = TextView(this).apply { text = "ASENA"; textSize = 32f; gravity = Gravity.CENTER }
        info = TextView(this).apply {
            text = "Türkçe sesli asistanın hazır. Mikrofonu başlatmak için izin ver."
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        fun button(label: String, action: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { action() } }

        layout.addView(title)
        layout.addView(info)
        layout.addView(button("ASENA'YI BAŞLAT") { startAssistant() })
        layout.addView(button("ASENA'YI DURDUR") {
            stopService(Intent(this, AsenaVoiceService::class.java))
            info.text = "Asistan durduruldu."
        })
        layout.addView(button("KİŞİLERİMİ GÜVENLİ AÇ") { unlockContacts() })
        layout.addView(button("FOTOĞRAF / DOSYA SEÇ") {
            val i = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
            startActivityForResult(i, 200)
        })
        layout.addView(button("BİLDİRİM ERİŞİM AYARLARI") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        layout.addView(button("SMS YAZ") {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        })
        layout.addView(button("ARAMA YAP") {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")))
        })
        setContentView(layout)
        requestBasicPermissions()
    }

    private fun requestBasicPermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(permissions.toTypedArray(), 10)
        }
    }

    private fun startAssistant() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestBasicPermissions()
            info.text = "Önce mikrofon izni vermelisin."
            return
        }
        ContextCompat.startForegroundService(this, Intent(this, AsenaVoiceService::class.java))
        info.text = "ASENA çalışıyor. Dinleme bildirimi ekranda görünür."
    }

    private fun unlockContacts() {
        val prompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), 11)
                    } else {
                        showContacts()
                    }
                }
                override fun onAuthenticationError(code: Int, message: CharSequence) {
                    super.onAuthenticationError(code, message)
                    info.text = "Doğrulama yapılmadı. Kişiler açılmadı."
                }
            })
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("ASENA güvenlik doğrulaması")
            .setSubtitle("Kişileri görmek için parmak izini veya cihaz kilidini doğrula")
            .setAllowedAuthenticators(
                BiometricPrompt.AUTHENTICATORS_BIOMETRIC_WEAK or
                    BiometricPrompt.AUTHENTICATOR_DEVICE_CREDENTIAL
            )
            .build()
        prompt.authenticate(promptInfo)
    }

    private fun showContacts() {
        val names = mutableListOf<String>()
        contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            null, null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )?.use { cursor ->
            val index = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            while (cursor.moveToNext() && names.size < 30) {
                if (index >= 0) names.add(cursor.getString(index))
            }
        }
        info.text = if (names.isEmpty()) "Kayıtlı kişi bulunamadı." else
            "Kişiler (en fazla 30):\n" + names.distinct().joinToString("\n")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 11 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) showContacts()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val engine = tts ?: return
            val result = engine.setLanguage(Locale("tr", "TR"))
            ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
            // Prefer a Turkish voice whose metadata marks it as female, if the device exposes one.
            val femaleVoice = engine.voices?.firstOrNull {
                it.locale.language == "tr" && it.features?.contains("female") == true
            }
            if (femaleVoice != null) engine.voice = femaleVoice
            if (!ttsReady) info.text = "Türkçe ses paketi telefonda bulunamadı; ayarlardan Türkçe TTS yükleyebilirsin."
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
