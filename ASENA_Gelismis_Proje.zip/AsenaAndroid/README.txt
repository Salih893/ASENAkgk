ASENA GELİŞMİŞ BAŞLANGIÇ PROJESİ

Gereksinimler:
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK 35

Özellikler:
- Türkçe SpeechRecognizer ile ses tanıma
- Android TextToSpeech ile Türkçe sesli cevap
- Cihazda varsa metadata'sında female özelliği olan Türkçe ses tercih edilir
- Kullanıcı başlatınca mikrofon foreground service ve görünür bildirim
- Kişi listesi ekranından önce biyometrik/cihaz kilidi doğrulaması
- Dosya/fotoğraf seçici (uygulama tüm depolamayı taramaz)
- SMS yazma ekranını açma; SMS içeriklerini gizlice okumaz
- Telefon arama ekranını açma; otomatik arama yapmaz
- Bildirim erişimi için Android ayar ekranına kısayol; bildirim içeriği saklanmaz

ÖNEMLİ ANDROID SINIRLARI:
- Mikrofon servisi kullanıcı uygulamayı açıp başlattığında çalışır; Android pil/arka plan
  politikaları servisi durdurabilir. Kesintisiz çalışma garanti edilemez.
- Android 14+ mikrofon foreground service başlatma kurallarına tabidir.
- SMS ve arama kayıtlarını okuma izinleri Android/Google Play tarafından ciddi biçimde
  kısıtlanır; bu başlangıç sürümü bunları okumaz.
- Bildirim erişimi kullanıcı tarafından Ayarlar'dan ayrıca etkinleştirilmelidir.
- Parmak izi cihazda yoksa Android cihaz kilidi kimlik doğrulaması yedek olarak sunulabilir.
- "Kadın sesi" telefonun Türkçe TTS motorunda böyle bir ses bulunmasına bağlıdır.
- Bu sürüm genel amaçlı yapay zekâ değildir; komutlar tek tek eklenerek genişletilir.
